function a=boots_q(a, b,c,d,e)
[a]=roots([a, b, c, d e]);
end