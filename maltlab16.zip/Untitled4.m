
tacc=1.0;
T1=2.0;
T2=2.0;
T3=2.0;
tdec=1.0;
J=2;
for i=1:n
jerk=J.*(t(i)<tacc||t(i)>(2*tacc+T1+T3+T2+tdec))-J.*((t(i)<(T1+2*tacc)&&t(i)>(T1+tacc))||(t(i)>(T1+2*tacc+T3)&&t(i)<(T1+2*tacc+T3+tdec)));
end
plot(jerk);