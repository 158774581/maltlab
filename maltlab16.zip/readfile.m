fid = fopen('C:\Users\hqi\Desktop\motion_w\motion_w\a.txt');
comma  = char(' ');
a = fscanf(fid, ['%f', comma]);

fclose(fid);
[m,n]=size(a);
a(m)
step=0.01;
fid1 = fopen('C:\Users\hqi\Desktop\motion_w\motion_w\v.txt');
comma  = char(' ');
v = fscanf(fid1, ['%f', comma]);
fclose(fid1);
v(m)
fid2 = fopen('C:\Users\hqi\Desktop\motion_w\motion_w\d.txt');
comma  = char(' ');
d = fscanf(fid2, ['%f', comma]);
d(m)
fclose(fid2);
subplot(311);
plot([0:step:m*step-step],a);
subplot(312);
plot([0:step:m*step-step],v);
subplot(313);
plot([0:step:m*step-step],d);